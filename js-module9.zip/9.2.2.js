//Дана заготовка и результат, который вы должны получить. Ваша задача — написать код, который 
//будет преобразовывать JSON в JS-объект и выводить его в консоль.

// JSON:

// {
//  "list": [
//   {
//    "name": "Petr",
//    "age": "20",
//    "prof": "mechanic"
//   },
//   {
//    "name": "Vova",
//    "age": "60",
//    "prof": "pilot"
//   }
//  ]
// }

// JS-объект:

// {
//   list: [
//     { name: 'Petr', age: 20, prof: 'mechanic' },
//     { name: 'Vova', age: 60, prof: 'pilot' },
//   ]
// }

const jsonString = 
`
{
    "list": [
     {
      "name": "Petr",
      "age": "20",
      "prof": "mechanic"
     },
     {
      "name": "Vova",
      "age": "60",
      "prof": "pilot"
     }
    ]
}
`;
let list = [];
let count = JSON.parse(jsonString).list.length;
for (let i = 0; i < count; i++) {
    let obj = {
        name: JSON.parse(jsonString).list[i].name,
        age: JSON.parse(jsonString).list[i].age,
        prof: JSON.parse(jsonString).list[i].prof
    }
    list.push(obj);
}
console.log("list", list);


